#ifndef BREAKPOINTS_H
#define	BREAKPOINTS_H

void init_complete();
void measurement_start();
void measurement_end();
void adc_done();

#endif	/* BREAKPOINTS_H */
