/* 
 * ID              : 	 
 * Name and Surname:
 */

#pragma config OSC = HSPLL, FCMEN = OFF, IESO = OFF, PWRT = OFF, PBADEN = OFF, BOREN = OFF, WDT = OFF, MCLRE = ON, LPT1OSC = OFF, LVP = OFF, XINST = OFF, DEBUG = OFF


#include <xc.h>
#include "breakpoints.h"


/********** Global Declarations ***********/



/********** Interrupt Routine *************/
void __interrupt(high_priority) highPriorityISR(void) {
    
    
}


/***** Write your main function here ******/
void main(void){
    
    
}