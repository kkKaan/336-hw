import math
from mdb import *
from grading import *

# Timeout for waiting for program to arrive to init_complete
INIT_TIMEOUT = 10000

prelude =  """
device PIC18F4620
set warningmessagebreakoptions.W0223_ADC_UNDERFLOW ignore
set warningmessagebreakoptions.W0222_ADC_OVERFLOW ignore
set oscillator.frequency 1
set oscillator.frequencyunit Mega
hwtool sim
"""


rubric = [
    ["RB Port Change Interrupt", 2.5],
    ["Timer interrupts enabled", 2.5],

    ["ADC Measurement Clear LEDs", 2.5],
    ["Breakpoint adc_done", 7.5],
    ["ADC: 4.6s with 1.0s precision", 5.0],
    ["ADC: 2.7s with 0.2s precision", 5.0],
    ["ADC: 4.6s with 0.5s precision", 10.0],
    ["ADC: 4.6s with 0.2s precision", 10.0],
]


def report_grade(name: str, correct, max_correct):
    global report
    print("Correct/Max:", f"{correct} / {max_correct}")
    report.set_grade(name, correct / max_correct)


def led_check(name: str, history, expected):
    def led_grade(a, b):
        return (0.5 * (a.latc == b[0])) + (0.5 * (a.latd == b[1]))
    grades = [a.timing_grade(e[2]) * led_grade(a, e) for a, e in zip(history, expected)]
    print("Expected:")
    print("PORTC:    ", " ".join(["{:>4}".format(hex(e[0])) for e in expected]))
    print("PORTD:    ", " ".join(["{:>4}".format(hex(e[1])) for e in expected]))
    print("Time (ms):", " ".join(["{:>4}".format(str(int(e[2] / 1000))) for e in expected]))
    print("Output:")
    print("PORTC:    ", " ".join(["{:>4}".format(hex(e.latc)) for e in history]))
    print("PORTD:    ", " ".join(["{:>4}".format(hex(e.latd)) for e in history]))
    print("Time (ms):", " ".join(["{:>4}".format(str(e.time // 1000)) for e in history]))
    print("Points:   ", " ".join(["{:>4}".format(grade) for grade in grades]))
    report_grade(name, sum(grades), len(expected))


def led_expectation(total_cycles, precision):
    # Passed time in microseconds
    passed = 0
    expected = []
    while total_cycles > 0:
        time = min(total_cycles, precision)
        i = passed / 1e6
        # Plus 0.1 to avoid floating point issues
        latc = math.floor(i + 0.1)
        latd = math.floor((i - latc) * 10 + 0.1)
        expected.append((2**latc - 1, 2**latd - 1, time))
        total_cycles -= time
        passed += time
    return expected


#########
# TESTS #
#########

def rbie_test(m):
    """
    Checks whether the PORTB inputs are handled via interrupts.
    """
    global report
    expect = report.get_expect_func("RB Port Change Interrupt", 4)

    m.breakpoint("init_complete")
    m.run(INIT_TIMEOUT)
    m.clear_breakpoints()

    intcon = m.get("INTCON")
    print("INTCON:", bin(intcon))
    expect(intcon & 8, "RBIE must be set when init_complete is reached")
    expect(intcon & 1 == 0, "RBIF must be cleared when init_complete is reached")
    
    def test(button):
        print()
        button_name = button.upper()
        m.exec("write pin "+ button +" high")
        #click_button(m, button)
        bp = m.run_timeout(INIT_TIMEOUT)
        expect(bp, "Must hit the breakpoint measurement_(start/end) after clicking " + button_name)
        m.stepi(10_000)
        m.exec("write pin "+ button +" low")

    m.breakpoint("measurement_start")
    test("rb4")
    m.clear_breakpoints()
    m.breakpoint("measurement_end")
    test("rb5")
    
    print()
    expect = report.get_expect_func("Timer interrupts enabled", 2)
    expect(m.get("PIE1") & 1, "TMR1IE must be set for ADC")
    click_button(m, "rb4")
    expect(m.get("INTCON") & 32, "TMR0IE must be set while measuring")
    click_button(m, "rb5")
    



def adc_test(m):
    """
    Alter the precision value using analog input and make measurements.
    """
    global report
    expect = report.get_expect_func("ADC Measurement Clear LEDs", 10)
    adc_expect = report.get_expect_func("Breakpoint adc_done", 9)

    m.breakpoint("init_complete")
    m.run(INIT_TIMEOUT)
    m.clear_breakpoints()
    
    m.breakpoint("adc_done")
    bp = m.run(110_000)
    adc_expect(bp, "Must hit the breakpoint adc_done every 100ms")
    adc_expect(m.get("PIE1") & 64, "ADIE must be set for ADC")
    bp = m.run(110_000)
    adc_expect(bp, "Must hit the breakpoint adc_done every 100ms")
    m.clear_breakpoints()
    
    latc = m.get("LATC")
    latd = m.get("LATD")
    print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after init_complete")
    expect(latc == 0, "After init_complete, PORTC LEDs must be off")
    expect(latd == 0, "After init_complete, PORTD LEDs must be off")
    

    def measure(name: str, iterations, cycles, new_volt, precision):
        print()
        print(f"Measurement: {(iterations*cycles)/1e6} s with {precision/1e6} s precision")
        m.exec("write pin rb4 high")

        update_AN0(m, new_volt)
	
        history = record_leds(m, iterations, cycles)
        expected = led_expectation(iterations * cycles, precision)
        led_check(name, history, expected)

        # End
        click_button(m, "rb5")
        m.exec("write pin rb4 low")

        latc = m.get("LATC")
        latd = m.get("LATD")
        print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after RB5")
        expect(latc == 0, "After RB5, PORTC LEDs must be off")
        expect(latd == 0, "After RB5, PORTD LEDs must be off")
    
    def set_AN0(value):
        m.breakpoint("highPriorityISR")
        m.breakpoint("adc_done")
        update_AN0(m, value)
        bp = m.run_timeout(INIT_TIMEOUT)
        adc_expect(bp and int(bp, 16) == 8, "Must hit 0x08 breakpoint - ADC should be handeled with interrupts")
        bp = m.run_timeout(INIT_TIMEOUT)
        adc_expect(bp, "Must hit the breakpoint adc_done after analog update")
        if not bp:
            # Breakpoint didn't hit, halt
            m.exec("halt")
        m.clear_breakpoints()

    set_AN0(0.0)
    measure("ADC: 4.6s with 1.0s precision", 92, 50_000, 4.0, 1000_000)
    measure("ADC: 2.7s with 0.2s precision", 54, 50_000, 0.0, 200_000)

    set_AN0(2.5)
    measure("ADC: 4.6s with 0.5s precision", 92, 50_000, 2.5, 500_000)
    
    set_AN0(4.0)
    measure("ADC: 4.6s with 0.2s precision", 92, 50_000, 4.0, 200_000)
    
    


if __name__ == "__main__":
    report = Report(rubric)

    tester = MdbTester(prelude)
    tester.run([
        rbie_test,
        adc_test,
    ])

    print()
    print(report.report_str())
    report.save_grades("grades3.pkl")
