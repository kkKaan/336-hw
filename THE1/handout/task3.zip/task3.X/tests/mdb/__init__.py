from .wrapper import Mdb
from .preprocess import *
from time import time

class MdbTester:
    def __init__(self, prelude: str):
        self.prelude = prelude.strip() + "\nprogram " + ELF_FILE
        self.m = None

    def run(self, tests: list):
        print("INITIALIZING...")
        start_time = time()
        try:
            check_files()
            self.m = Mdb()
            self.m.prelude(self.prelude)
        except TestFailed as e:
            print("INITIALIZATION FAILED:", e)
            return
        else:
            print("INITIALIZATION SUCCESSFUL")

        for test in tests:
            print("\n\nRUNNING TEST:", test.__name__)
            if test.__doc__ is not None:
                print("\t" + test.__doc__.strip())
            try:
                test(self.m)
            except TestFailed as e:
                print("TEST FAILED:", e)
            finally:
                self.m.reset()
        print("\nFinished executing tests in %.2f seconds." % (time() - start_time))
        self.m.quit()

