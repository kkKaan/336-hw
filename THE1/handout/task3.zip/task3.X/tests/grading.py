import pickle
from dataclasses import dataclass


class Report:
    def __init__(self, rubric: list):
        self.grades = {}
        self.rubric = rubric

    def set_grade(self, name: str, grade: float, print_grade: bool = True):
        self.grades[name] = grade
        matches = [r for r in self.rubric if r[0] == name]
        if len(matches) != 1:
            raise ValueError("Rubric error: " + str(matches))
        if print_grade:
            r = matches[0]
            scaled = round(grade * r[1], 2)
            print(f'Grade for "{r[0]}": {scaled:.2f} / {r[1]:.1f}')

    def print_grade(self, name: str):
        grade = self.grades[name]
        matches = [r for r in self.rubric if r[0] == name]
        if len(matches) != 1:
            raise ValueError("Rubric error: " + str(matches))
        r = matches[0]
        scaled = round(grade * r[1], 2)
        print(f'Grade for "{r[0]}": {scaled:.2f} / {r[1]:.1f}')

    def get_expect_func(self, name: str, items: int):
        correct = 0
        total = 0
        def func(test, info: str):
            nonlocal correct, total
            total += 1
            if test:
                print(info+": PASS")
                correct += 1
            else:
                print(info+": FAILED")
            grade = correct / items
            self.set_grade(name, grade, False)
            if total > items:
                print("GRADER:", name, "expect func total must be at least", total)
        return func

    def save_grades(self, filename):
        with open(filename, 'wb') as f:
            pickle.dump(self.grades, f)

    def load_grades(self, filename):
        with open(filename, 'rb') as f:
            self.grades = pickle.load(f)

    def report_items(self):
        def process_rubric_item(r):
            grade = self.grades[r[0]] if r[0] in self.grades else 0.0
            grade = round(grade * r[1], 2)
            return [r[0], grade, r[1]]
        grade_items = [process_rubric_item(g) for g in self.rubric]
        f = "{0:>5} / {1:>4}  {2}"
        total_grade = round(sum([g[1] for g in grade_items]), 2)
        max_grade = round(sum([g[1] for g in self.rubric]), 2)
        return [g + [f.format(g[1], g[2], g[0])] for g in grade_items], total_grade, max_grade

    def report_str(self):
        grade_items, total_grade, max_grade = self.report_items()
        grade_report = "\n".join([g[3] for g in grade_items])
        return f"GRADE\n{grade_report}\nTOTAL GRADE: {total_grade:.2f}/{max_grade:.2f}"


def bin8(value: int):
    """
    Convert 8-bit register value to binary representation.
    """
    return ("0"*8 + bin(value)[2:])[-8:]



TIMING_ERROR_MARGIN = 60e3

def timing_grade(time, target):
    error = abs(target-time)
    if error <= TIMING_ERROR_MARGIN:
        return 1.0
    else:
        return 0


@dataclass
class LedRecording:
    latc: int
    latd: int
    time: int

    def timing_grade(self, target):
        return timing_grade(self.time, target)


def record_leds(m, iterations, cycles):
    history = []
    latc = m.get("LATC")
    latd = m.get("LATD")
    current = LedRecording(latc, latd, 0)
    print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  at the start")
    for _ in range(iterations):
        time = m.cycle(cycles)
        latc = m.get("LATC")
        latd = m.get("LATD")
        current.time += time
        if latc != current.latc or latd != current.latd:
            print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after {current.time/1e6} s")
            history.append(current)
            current = LedRecording(latc, latd, 0)
    print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after {current.time/1e6} s (end)")
    history.append(current)
    return history
    
def record_leds_after_change(m, passed_time, iterations, cycles):
    history = []
    latc = m.get("LATC")
    latd = m.get("LATD")
    current = LedRecording(latc, latd, passed_time)
    print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  at the start")
    for _ in range(iterations):
        time = m.cycle(cycles)
        latc = m.get("LATC")
        latd = m.get("LATD")
        current.time += time
        if latc != current.latc or latd != current.latd:
            print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after {current.time/1e6} s")
            history.append(current)
            current = LedRecording(latc, latd, 0)
    print(f"PORTC: {bin8(latc)}  PORTD: {bin8(latd)}  after {current.time/1e6} s (end)")
    history.append(current)
    return history


    
def update_AN0(m, v):
    """
    Update AN0 with v, wait 100ms
    """
    print("Updating AN0 with {:.1f} Volts...".format(v))
    m.exec("write pin AN0 {:.1f}V".format(v))
    m.cycle(10_000)

def click_button(m, pin):
    """
    Press the button, wait 10ms, release the button
    """
    print("Pressing & releasing "+ pin.upper() + "...")
    m.exec("write pin " + pin + " high")
    m.cycle(10_000)
    m.exec("write pin " + pin + " low")

def hold_button(m, pin):
    """
    Press the button
    """
    print("Holding "+ pin.upper() + "...")
    m.exec("write pin " + pin + " high")

def release_button(m, pin):
    """
    Release the button
    """
    print("Releasing "+ pin.upper() + "...")
    m.exec("write pin " + pin + " low")
