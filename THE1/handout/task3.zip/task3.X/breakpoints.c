#include "breakpoints.h"

void init_complete() {}
void measurement_start() {}
void measurement_end() {}
void adc_done() {}
