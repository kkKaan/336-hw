#ifndef BREAKPOINTS_H
#define	BREAKPOINTS_H

void init_complete();
void measurement_start();
void measurement_end();



#endif	/* BREAKPOINTS_H */
