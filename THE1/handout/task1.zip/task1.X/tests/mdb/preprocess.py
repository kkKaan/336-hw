# Preprocessing steps: loading files, breakpoints, etc.
import os
import pathlib
from .exceptions import *

PROJECT_NAME = pathlib.Path().absolute().parent.name

if PROJECT_NAME.endswith(".X"):
    ELF_FILE = f"../dist/default/production/{PROJECT_NAME}.production.elf"
    CMF_FILE = f"../dist/default/production/{PROJECT_NAME}.production.cmf"
    C_FILE = "../task1.c"
else:
    print(f"Parent directory ({PROJECT_NAME}) doesn't end with .X")
    print("You are probably running the script in the wrong directory.")

def check_files():
    """
    Check if .elf, .cmf, and .s files exist.
    """
    if not os.path.isfile(C_FILE):
        # Testing setup is wrong if no C file
        raise MdbException("C_FILE not found!")
    if not os.path.isfile(ELF_FILE) or not os.path.isfile(CMF_FILE):
        # This must be because compile failed
        raise TestFailed("Compile failed!")

